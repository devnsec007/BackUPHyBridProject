package src.qa.commonfunctions;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class TableSearch {

	WebDriver driver;
	
	public Boolean TableSearchTruFalse(WebDriver driver,List<WebElement> TableElement,String SearchElement) {
		
		this.driver=driver;
		Boolean SuccessFailure =false;
		
		for(WebElement ROWELE:TableElement) {
			
			List<WebElement> CellLIST =ROWELE.findElements(By.tagName("td"));
			
			for(WebElement CELLELE:CellLIST) {
			
				if(CELLELE.getText().contains(SearchElement)) {
					
					SuccessFailure =true;
					break;
				}
			}
			
		}
		
		
		
		return SuccessFailure;
	}
	
	
}
