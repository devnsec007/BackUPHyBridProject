package com.qa.pages;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import src.qa.commonfunctions.TableSearch;

public class TableSearchAndSortPage {

	private  WebDriver driver;
	
	TableSearch TSElement;
	
	
	public TableSearchAndSortPage(WebDriver driver) {
		
		this.driver = driver;
		PageFactory.initElements(driver, this);
		TSElement = new TableSearch();
		
	}
	
	@FindBy(xpath="//ul[@class='nav navbar-nav']/li[3]")
	WebElement TableNavigation;
	
	@FindBy(xpath="//li[@class='dropdown open']//child::ul/li[4]")
	WebElement SearchAndSortNaviGation;
	
	@FindBy(xpath="//div[@class='col-md-6 text-left']/h2")
	WebElement NameOfThePage;
	
	@FindBy(xpath="//div[@id='example_filter']//label//input")
	WebElement SearchElement;
	
	@FindBy(xpath="//table[@id='example']/tbody/tr")
	List<WebElement> TableRow;
	
	
	public String NavigateToSearch() {
		
		TableNavigation.click();
		SearchAndSortNaviGation.click();
		return(NameOfThePage.getText().toString());
				
	}
	
	public Boolean SearchOntheTable(String Name) {
		
		SearchElement.sendKeys(Name);
		
		return TSElement.TableSearchTruFalse(driver,TableRow, Name);
	}
	
	
	
	
}
